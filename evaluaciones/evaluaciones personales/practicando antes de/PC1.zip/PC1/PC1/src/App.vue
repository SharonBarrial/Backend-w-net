<script setup>


import ToolbarComponent from "@/fakezooapi/components/toolbar.component.vue";
import FooterComponent from "@/fakezooapi/components/footer.component.vue";
import ZooList from "@/fakezooapi/components/zoo-list.component.vue";
</script>

<template>
  <toolbar-component/>
  <zoo-list/>
  <footer-component/>
</template>
<style scoped>
</style>