<script>
export default{
  name: "footerComponent"
}
</script>

<template>
  <footer class="text-center">
    <h1>{{ $t('copyright')}}</h1>
    <br>
    <h4>{{$t('delovep')}}</h4>
  </footer>
</template>

<style scoped>

</style>