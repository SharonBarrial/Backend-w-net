<script>
export default{
  name: "toolbarComponent"
}
</script>

<template>
  <pv-toolbar class="text-center">
    <template #start>
      <h1>{{ $t('zootitle')}}</h1>
    </template>
  </pv-toolbar>
</template>

<style scoped>

</style>