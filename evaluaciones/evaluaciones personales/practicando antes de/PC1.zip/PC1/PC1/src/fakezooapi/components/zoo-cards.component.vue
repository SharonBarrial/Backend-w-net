<script>
import {zoos} from "@/fakezooapi/models/zoos.entity.js";
import { ref } from 'vue';

const value = ref(null);
export default{
  name: "zoo-card",
  props: {
    zoo: {
      type: zoos,
      required: true
    }
  }
}
</script>

<template>
  <div class=" align-items-center justify-content-center m-4 ">

    <pv-card style="width: 22rem; overflow: hidden">
      <template #title> {{ $t('zooname')}} {{zoo.name}}</template>
      <template #subtitle>
        <img :src="zoo.image"/>
      </template>
      <template #content>{{ $t('zoohabitat')}}{{zoo.habitat}}<br/>{{$t('zoodescription')}}{{zoo.description}}</template>
      <template #footer>{{$t('zoofamily')}}{{zoo.family}}<br/>{{$t('url')}}{{zoo.image}}
        <div class="card d-flex justify-content-center align-items-center flex-row">
          <pv-rating v-model="value" :cancel="false" />
        </div>
      </template>
    </pv-card>
  </div>
</template>

<style>

</style>
