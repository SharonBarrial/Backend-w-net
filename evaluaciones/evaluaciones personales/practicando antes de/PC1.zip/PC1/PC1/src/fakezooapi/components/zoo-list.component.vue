<script>

import {ZooServiceServices} from "@/fakezooapi/services/zoo-service.services.js";
import ZooCard from "@/fakezooapi/components/zoo-cards.component.vue";

export default{
  name: "zoo-list",
  components: {ZooCard},
  data(){
    return{
      zooapi: new ZooServiceServices(),
      zooAnimals :[]
    }
  },
  created(){
    this.zooapi.getUniversities().then(response => this.zooAnimals = response.data).catch(error => {this.zooAnimals.push("Se encontre el siguiente error:" + error)})
  }
}
</script>

<template>
  <div class="grid col-fixed align-items-center justify-content-center">
    <zoo-card v-for="zoo in zooAnimals" :key="zoo.id" :zoo="zoo"/>
  </div>
</template>

<style scoped>

</style>