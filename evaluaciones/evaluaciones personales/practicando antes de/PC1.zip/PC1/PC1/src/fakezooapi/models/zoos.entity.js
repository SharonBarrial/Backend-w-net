export class zoos{
    name;
    image;
    habitat;
    description;
    family;

    constructor(name, image, habitat, description, family){
        this.name = name;
        this.image = image;
        this.habitat = habitat;
        this.description = description;
        this.family = family;
    }

}