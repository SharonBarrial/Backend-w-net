import axios from "axios";

const http = axios.create({
    baseURL: "https://freetestapi.com/api/v1/animals?limit=10",
});

export class ZooServiceServices {
    getUniversities() {
        return http.get('')
    }
}