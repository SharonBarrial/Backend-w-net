const en = {
    hello: 'Hello',
    zootitle: 'FakeZoo API Showcase',
    zooname: 'Animal: ',
    zoohabitat: 'Habitat: ',
    zoodescription: 'Description: ',
    zoofamily: 'Family: ',
    url: 'Link: ',
    copyright: 'Copyright © 2024 Fake Store, inc. All rights reserved.',
    delovep: 'Developed by Juan Alejandro Cuadros Rodriguez (u20221a359)'
}

export default en