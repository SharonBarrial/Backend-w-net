const es = {
    hello: 'Hola',
    zootitle: 'Vitrina de la API FakeZoo',
    zooname: 'Animal :',
    zoohabitat: 'Hábitat: ',
    zoodescription: 'Descripción: ',
    zoofamily: 'Familia: ',
    url: 'Enlace: ',
    copyright:'Derechos de autor © 2024 Fake Store, inc. Todos los derechos reservados.',
    delovep: 'Desarrollado por Juan Alejandro Cuadros Rodriguez (u20221a359)'
}
export default es