//El proposito del proyecto fue implementar los datos de un api a la pagina web, para ello se utilizo la api de fakestoreapi.com
//para obtener los datos de los productos y mostrarlos en la pagina web, se utilizo primevue para la implementacion de los componentes
//y se utilizo vue-i18n para la internacionalizacion de la pagina web, se implementaron dos idiomas, ingles y español.
//Se implementaron los componentes de primevue, card, rating y toolbar, se utilizo el componente de card para mostrar los productos
//de la api, el componente de rating para mostrar la calificacion de los productos y el componente de toolbar para mostrar el titulo
//de la pagina web.
//Autor: Juan Alejandro Cuadros Rodriguez
import 'primevue/resources/primevue.min.css' // Import PrimeVue CSS
import 'primeicons/primeicons.css' // Import PrimeIcons CSS


import { createApp } from 'vue'
import Toolbar from "primevue/toolbar"
import Card from "primevue/card"
import App from "./App.vue"
import PrimeVue from "primevue/config"
import i18n from "@/locale/i18n.js";
import Rating from 'primevue/rating';


const app = createApp(App)
app.use(PrimeVue)
app.use(i18n)

app.component('pv-rating',Rating)
app.component('pv-toolbar', Toolbar)
app.component('pv-card', Card)

app.mount('#app')