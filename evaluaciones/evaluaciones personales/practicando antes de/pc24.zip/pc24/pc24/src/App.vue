<script setup>
import Toolbar from "@/components/public/toolbar.component.vue";
import CardAnimal from "@/components/animals/card-animal.component.vue";
import AnimalsCards from "@/components/animals/animals-cards.component.vue";
import Footer from "@/components/public/footer.component.vue";
</script>

<template>
  <Toolbar></Toolbar>
  <h1>Animals</h1>
  <AnimalsCards/>
  <Footer></Footer>
</template>

<style scoped>

</style>
