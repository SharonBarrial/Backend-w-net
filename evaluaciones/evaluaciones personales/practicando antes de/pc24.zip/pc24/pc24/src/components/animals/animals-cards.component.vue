<script setup>
import CardAnimal from "@/components/animals/card-animal.component.vue";
</script>

<template>
  <ul>
    <li v-for="i in 50" >
      <CardAnimal :id="i" />
    </li>
  </ul>

</template>

<style scoped>
.card-animal{
  background-color: #f5e69c;
  padding: 0;
  text-align: center;
}
li{
  list-style: none;
}
.rating-animal{
  margin: auto;
  justify-content: center;
}

</style>