<script setup>
import getApiService from "@/services/animal.service.js"
import { ref, onMounted, defineProps } from "vue";

const props = defineProps(['id']);

const animal = ref({})
const value = ref(null);
onMounted(async () => {
  const response = await getApiService.getAnimal(props.id);
  animal.value = response.data;

  console.log(animal.value);
})

</script>

<template>

      <pv-card class="card-animal">

        <template #content >

            <h1>Name: {{animal?.name}}</h1>
            <img :src="animal?.image" alt="image of animal" width="200" height="200" />
            <h1>Habitat: {{animal?.habitat}}</h1>
            <h1>Description: {{animal?.description}}</h1>
            <h1>Family: {{animal?.family}}</h1>

        </template>
        <template #footer >
          <div class="card flex justify-content-center">
            <pv-rating class="rating-animal" v-model="value" :cancel="false"  />
            <h1 v-if="value">{{value}}.0</h1>
          </div>

        </template>
      </pv-card>

</template>

<style scoped>
.card-animal{
    background-color: #f5dc9c;
    padding: 0;
    text-align: center;
    max-width: 1280px;
    margin: 10px auto;
  }
li{
  list-style: none;
}
.rating-animal{
  margin: auto;
  justify-content: center;
}

</style>