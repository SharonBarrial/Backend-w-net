<script setup>

</script>

<template>
  <div class="footer-page">
    <footer  role="contentinfo">
      <p>Copyright © 2023 RESTCountries, inc All rights reserved. </p>
      <p>Developed by U20201B298 MIGUEL ANGEL YBAÑEZ ESQUERRE</p>
    </footer>
  </div>

</template>

<style scoped>
.footer-page{
  background-color: #1c1c1c;
  color: white;
  padding: 50px;
  text-align: center;
}
</style>