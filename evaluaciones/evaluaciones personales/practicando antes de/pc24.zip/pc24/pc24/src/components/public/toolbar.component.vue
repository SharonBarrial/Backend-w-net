<script setup>

</script>

<template>
  <pv-toolbar class="toolbar-page" role="banner">
    <template #center>
      <h1>Fake Zoo API Showcase</h1>
    </template>
  </pv-toolbar>
</template>

<style scoped>
.toolbar-page{
  background-color: #9ccdf5;
}
</style>