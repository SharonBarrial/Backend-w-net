import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
import PrimeVue from "primevue/config";
import 'primevue/resources/themes/aura-light-green/theme.css'

import Toolbar from 'primevue/toolbar';
import Card from 'primevue/card';
import Rating from 'primevue/rating';

const app = createApp(App);

app.use(PrimeVue);
app.component('pv-card', Card);
app.component('pv-toolbar', Toolbar);
app.component('pv-rating', Rating);
app.mount('#app')
