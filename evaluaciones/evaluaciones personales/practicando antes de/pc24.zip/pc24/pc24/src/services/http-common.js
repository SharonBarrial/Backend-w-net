import axios from 'axios'

export default axios.create({
    baseURL: 'https://freetestapi.com/',
    headers:{
        'content-type': 'application/json',
    }
})