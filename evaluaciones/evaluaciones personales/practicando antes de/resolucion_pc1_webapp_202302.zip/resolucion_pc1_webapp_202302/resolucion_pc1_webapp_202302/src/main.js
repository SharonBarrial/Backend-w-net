// Author: Choclitos
// Summary: Esta es la resolucion de la PC1 de Aplicaciones Web utilizando Axios, Primeflex, Primevue

import { createApp } from 'vue'
import './style.css'
import PrimeVue from 'primevue/config';
import Toolbar from 'primevue/toolbar';
import Card from 'primevue/card';
import Button from 'primevue/button';
import 'primevue/resources/themes/soho-light/theme.css'
import 'primeicons/primeicons.css';
import App from './App.vue'

createApp(App)
    .use(PrimeVue, { riple:true })
    .component('pv-toolbar', Toolbar)
    .component('pv-card', Card)
    .component('pv-button', Button)
    .mount('#app')
