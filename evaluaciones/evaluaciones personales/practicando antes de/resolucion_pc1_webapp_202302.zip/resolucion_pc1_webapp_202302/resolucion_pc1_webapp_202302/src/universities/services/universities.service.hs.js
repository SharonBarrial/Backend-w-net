import axios from "axios";

const http = axios.create({
    baseURL: 'http://universities.hipolabs.com/search?country=peru'
});

export class UniversityApiService {
    getUniversities() {
        return http.get('');
    }
}