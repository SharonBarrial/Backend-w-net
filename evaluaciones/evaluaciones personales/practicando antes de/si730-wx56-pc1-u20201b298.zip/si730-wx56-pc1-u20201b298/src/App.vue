<script setup>
import Toolbar from "@/components/public/toolbar.component.vue";
import Footer from "@/components/public/footer.component.vue";
import ProductsCard from "@/components/commerce/product/products-card.component.vue";
</script>

<template>
  <Toolbar/>
  <ProductsCard/>
  <Footer/>
</template>

<style scoped>

</style>
