<script setup>

</script>

<template>
<footer>
  <p>Copyright © 2024 Jelly Bean Peru Store, inc. All rights reserved.</p>
  <p>Developed by U20201B298 MIGUEL ANGEL YBAÑEZ ESQUERRE</p>
</footer>
</template>

<style scoped>
footer{
  text-align:center;
  background-color: #212121;
  color: white;
}
</style>