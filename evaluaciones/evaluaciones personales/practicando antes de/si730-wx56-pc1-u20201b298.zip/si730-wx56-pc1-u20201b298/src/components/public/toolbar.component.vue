<script setup>

</script>

<template>
  <pv-toolbar role="banner">
    <template #center>
      <h1>JellyBean Peru Store</h1>
    </template>
  </pv-toolbar>
</template>

<style scoped>

</style>