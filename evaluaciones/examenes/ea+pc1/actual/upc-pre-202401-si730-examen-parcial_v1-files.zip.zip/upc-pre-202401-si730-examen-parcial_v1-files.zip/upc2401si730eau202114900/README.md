# upc2401si730eau202114900
### Autor
- Names: Sharon Antuantet Ivet
- Last Name: Barrial Marin
- Code: u20114900

> Hi, I'm Sharon, a student of Software Engineering at the 
> Peruvian University of Applied Sciences. I'm 21 years old.
> I'm actually learning about Vue and I'm very excited to learn more about it.
> Altought I'm not an expert and it's very difficult to me.
> I'm very happy to be part of this course and I hope to learn a lot from it.
> If you want to contact me, you can do it through my email: u202114900@upc.edu.pe
> I hope you have a great day.
> Thank you for reading this.

## Case Study -  Frontend

#### Hartford Institute for Geriatric Nursing.

## Purpose

This project has like a function show cards for examiners and 

## Features

This project 

## Dependencies

- Node.js
- npm
- Vue.js
- Vite
- axios

## Libraries:
- axios
- vue-router
- primevue
- primeicons
- primeflex
- vue-i18n

## Framework

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs,
check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.


-----------------------------------------------------------------------


## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```
