<script setup>
import TheToolbar from '@/core/public/components/the-toolbar.component.vue'

</script>

<template>
  <the-toolbar></the-toolbar>
  <router-view></router-view>
</template>

<style scoped>


</style>