<script>

import { ExaminerService } from '@/core/nursing/services/examiner.service.js'
import { defineComponent } from "vue";
export default defineComponent({
  name: 'examiner-view',
  data() {
    return {
      examinerService: new ExaminerService(),
      examiners: [],
      loading: false,
    }
  },
  methods: {
    async getExaminerPerformanceOverview() {
      try {
        this.loading = true;
        this.examiners = await this.examinerService.getExaminerPerformanceOverview();
        this.loading = false;
      } catch (error) {
        console.error('Error fetching Examiner Performance Overview:', error);
        this.loading = false;
      }
    },
  },
  created() {
    this.getExaminerPerformanceOverview();
  }
});
</script>

<template>
  <div class="container">
    <pv-card v-for="examiner in examiners" :key="examiner.fullName">
      <template #header>

      </template>
      <template #title>{{ examiner.fullName }}</template>
      <template #content>
        <p><strong>NPI:</strong> {{ examiner.NPI }}</p>
        <p><strong>Mental State Exam Performance</strong></p>
        <p><strong>Current Assigned Mental State Exam Count:</strong> {{ examiner.currentExamCount }}</p>
        <p><strong>Average Assigned Mental State Exam Total Score:</strong> {{ examiner.averageScore }}</p>
      </template>
    </pv-card>
  </div>
</template>

<style scoped>

.container{
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
  gap: 1rem;
}

pv-card{
  width: 25rem;
  overflow: hidden;
  margin: 25px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);

}

</style>

