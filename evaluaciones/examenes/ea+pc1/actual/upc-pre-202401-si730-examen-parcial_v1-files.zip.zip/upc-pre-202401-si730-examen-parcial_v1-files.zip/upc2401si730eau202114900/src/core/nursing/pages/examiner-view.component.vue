<script>
import ExaminerView from '@/core/nursing/components/card-examiners.vue'

export default {
  name: 'examiner-view.component',
  components: { ExaminerView }
}
</script>

<template>
  <examiner-view></examiner-view>
</template>

<style scoped>

</style>