<script >
import { ExaminerService } from '@/core/nursing/services/examiner.service.js'
import { defineComponent } from 'vue'

export default defineComponent({
  components: { },
  data() {
    return {
      loading: true,
      patientsWithSupervisors: [],
      examCount: 0,
      highestScore: 0,
      lowestScore: 0,
      averageScore: 0
    };
  },
  async created() {
    try {
      const examinerService = new ExaminerService();
      const { examCount, highestScore, lowestScore, averageScore, patientData } = await examinerService.getAllExaminers();
      this.examCount = examCount;
      this.highestScore = highestScore;
      this.lowestScore = lowestScore;
      this.averageScore = averageScore;
      this.patientsWithSupervisors = patientData;
    } catch (error) {
      console.error("Error fetching health checks overview:", error);
    } finally {
      this.loading = false;
    }
  }
});

</script>

<template>
  <div class="container-home" aria-label="Home Page">
    <div class="hero-section">
      <h3 class="hero-section-phrase">{{ $t('HeroSectionPhrase')}}</h3>
      <h1>Mental State Exam Analytics</h1>
      <p>Exam Count: {{ examCount }}</p>
      <p>Highest Score: {{ highestScore }}</p>
      <p>Lowest Score: {{ lowestScore }}</p>
      <p>Average Score: {{ averageScore }}</p>
    </div>
  </div>
</template>


<style scoped>

pv-card{
  color: black;
}



.hero-section-phrase {
  text-align: center;
  padding: 20px
}

h3{
  font-size: 3em;
  color: white;
  text-shadow: black -1px 5px 10px;
  line-break: inherit;
  line-height: 8dvb;
  font-weight: bolder;
  font-family: 'Roboto', sans-serif;
  justify-items: center;
}
.container-home{
  background-color: darkgray;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 89vh;
}

pv-button{
  background-color: mediumpurple; /* Green background */
  border: none; /* Remove border */
  color: white; /* White text */
  padding: 15px 32px; /* Some padding */
  text-align: center; /* Centered text */
  text-decoration: none; /* Remove underline */
  display: inline-block; /* Get it to display inline */
  font-size: 16px;
  cursor: pointer;
  font-weight: bold;
  border-radius: 10px;
  margin: 0 1rem 0 0;
  /*text-align: center;
  justify-content: center;
  align-content: center;
  align-items: center;*/
}

@media screen and (max-width: 400px) {
  .hero-section{
    margin: 10px 20px;
  }
}
</style>