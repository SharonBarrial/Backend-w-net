<script >
import { useRoute } from 'vue-router'

export default {
  name: "page-not-found",
  setup() {
    //this function is used to get the current route path and display it in the template
    const route = useRoute();
    return {
      routePath: route.path
    };
  }
}

</script>

<template>
  <div aria-label="Page not found">
    <h1>Page not found</h1>
    <p>Sorry, the page "{{ routePath }}" that you are looking for does not exist.</p>
    <router-link to="/home">
      <pv-button>Go back home</pv-button>
    </router-link>
  </div>
</template>


<style scoped>
pv-button{
  background-color: mediumpurple; /* Green background */
  border: none; /* Remove border */
  color: white; /* White text */
  padding: 15px 32px; /* Some padding */
  text-align: center; /* Centered text */
  text-decoration: none; /* Remove underline */
  display: inline-block; /* Get it to display inline */
  font-size: 16px;
  cursor: pointer;
  font-weight: bold;
  border-radius: 10px;
  margin: 0 1rem 0 0;
  /*text-align: center;
  justify-content: center;
  align-content: center;
  align-items: center;*/
}

div {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  gap: 20px;
}
</style>




