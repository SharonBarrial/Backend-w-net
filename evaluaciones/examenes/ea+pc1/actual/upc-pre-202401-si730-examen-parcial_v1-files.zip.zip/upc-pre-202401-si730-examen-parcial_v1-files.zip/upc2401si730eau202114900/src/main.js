/*Here we import the PrimeVue library and its services, components, and styles.
We also import the PrimeIcons and PrimeFlex libraries, the theme,
the i18n configuration, and the router configuration.
 */
import { createApp } from 'vue'
import App from './app.vue'

import PrimeVue from "primevue/config";

import Card from "primevue/card";
import Toolbar from 'primevue/toolbar';
import Button from 'primevue/button';

import 'primevue/resources/primevue.min.css'
import 'primevue/resources/themes/aura-light-purple/theme.css'
import 'primeicons/primeicons.css'
import router from "@/router/index.js";
import i18n from '@/locales/i18n.js'

createApp(App)
  .use(PrimeVue,{ripple: true})
  .use(router)
  .use(i18n)
  .component('pv-card', Card)
  .component('pv-toolbar', Toolbar)
  .component('pv-button', Button)
  .mount('#app')