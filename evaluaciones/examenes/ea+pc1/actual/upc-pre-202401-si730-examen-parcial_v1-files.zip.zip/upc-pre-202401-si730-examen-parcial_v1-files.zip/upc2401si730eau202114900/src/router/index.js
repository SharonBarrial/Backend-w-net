//This file is used to create the router instance
// and export it to the main.js file.
// The createRouter function is used to create the router instance
// and the createWebHistory function is used to create the history instance.
// The routes property is used to define the routes for the application.
// The routes are defined in the routes.js file and imported into this file.

import { createRouter, createWebHistory } from "vue-router";
import { routes } from "./routes";

export const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});

export default router;