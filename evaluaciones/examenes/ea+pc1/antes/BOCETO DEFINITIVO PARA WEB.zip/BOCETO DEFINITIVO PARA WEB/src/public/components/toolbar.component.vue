<script>
import LanguageSwitcher from "./language-switcher.component.vue";
import router from "../../router/index.js";

export default {
  name: "toolbar-component",
  components: {LanguageSwitcher},
  data() {
    return {
      items: [
        {label: 'Home', to: '/home'},
      ],
      user: null,
    }
  },
  created() {

  },
  computed: {
    is_logged() {
      return true;
    },
  },
  methods: {

    sendToProfile() {
      router.push(
          {name: 'profile', params: {id: 1}}
      );
    },
    sendToCompany() {
      router.push(
          {name: 'company', params: {id: 1}}
      );
    },
    sendToRooms() {
      router.push(
          {name: 'rooms', params: {id: 1}}
      );
    },
    sendToSupply() {
      router.push(
          {name: 'supply', params: {id: 1}}
      );
    },

  }
}
</script>

<template>
  <pv-toolbar class="bg-primary pt-1 pb-1" style="border-radius: 0;">
    <template #start>
      <router-link v-if="is_logged" key="/" v-slot="{navigate, href}" to="/" class="ml-2">
        <pv-button :href="href" class="p-button-text text-white" @click="navigate">
          <h2> Sweet Manager</h2>
        </pv-button>
      </router-link>

    </template>

    <template #center>
      <language-switcher/>
    </template>

    <template #end>
      <div class="flex-column" v-if="is_logged">

        <pv-button class="p-button-text text-white" @click="sendToRooms()">
          Rooms
        </pv-button>

        <pv-button class="p-button-text text-white" @click="sendToSupply()">
          Supply
        </pv-button>

        <pv-button class="p-button-text text-white" @click="sendToCompany()">
          My Company
        </pv-button>

        <pv-button class="p-button-text text-white" @click="sendToProfile()">
          My Profile
        </pv-button>
      </div>
    </template>
  </pv-toolbar>
</template>

<style scoped>

</style>