import {createRouter, createWebHistory} from "vue-router";

import HomeContent from "../public/pages/home-content.vue";



const router = createRouter({
    history: createWebHistory(),
    routes: [
        {path: '/', component: HomeContent,}
    ]
});


export default router;