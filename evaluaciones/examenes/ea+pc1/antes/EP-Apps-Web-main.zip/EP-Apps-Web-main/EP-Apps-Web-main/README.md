# EP-Apps-Web
### Antes de empezar

1. Crea la carpeta donde residirá tu proyecto
2. Abre Webstorm, crea el proyecto en angular y selecciona la carpeta creada en el paso 1
3. Cuando webstorm termine de crear el proyecto
   dirigete a la siguiente sección **Durante el proceso**

### Durante el proceso
1. Abre el terminal de webstorm y ejecuta el siguiente comando:
```bash
npm install
```

2. Luego instala angular material con el siguiente comando:
```bash
ng add @angular/material
```
3. Para levantar el servidor coloca el siguiente comando:
```bash
ng serve -o
```

### Para crear componentes
1. Para crear un servicios abre otra terminal
   y coloca el comando: **ng g s** "nombre de tu servicio"
2. Para crear un componente **ng g c** "nombre de tu componente"

### Para levantar json
1. Abre otra terminal y coloca el siguiente comando:
   **cd** "nombre de tu carpeta"
2. Luego coloca el siguiente comando:
   **json-server --watch db.json --routes routes.json**

### Para instalar json-server
1. Abre otra terminal y coloca el siguiente comando:
   **npm install -g json-server@0.17.4**

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
