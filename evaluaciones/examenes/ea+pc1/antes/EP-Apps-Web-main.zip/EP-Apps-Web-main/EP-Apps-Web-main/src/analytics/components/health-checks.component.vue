<template>
  <div style="display:flex; flex-direction:column">
  <pv-card style="width: 25rem; overflow: hidden; margin:25px;" v-for="patient in patients" :key="patient.id">
    <template #header>
        <img alt="patient.fullName" :src="patient.photoUrl" />
    </template>
    <template #title>{{ patient.fullName }}</template>
    <template #content>
      <p><strong>Date of Birth:</strong> {{ patient.birthDate }}</p>
          <p><strong>Supervisor:</strong> {{ patient.supervisor }}</p>
          <p><strong>National Provider Identifier:</strong> {{patient.nationalProviderIdentifier}}</p>
          <p><strong>examDate: </strong>{{patient.examDate}}</p>
          <p><strong>Score:</strong> {{ patient.score }}</p>
    </template>
</pv-card>
</div>
</template>

<script>
import { defineComponent } from "vue";
import { HealthChecksService } from "../services/health-checks.service";

export default defineComponent({
  name: 'health-check-view',
  data() {
    return {
        healthChecksService: new HealthChecksService(),
        patients: [],
        loading: false, // Add loading state
    }
  },
  methods: {
    async getAllPatientsWithSupervisors() {
        try {
            this.loading = true; 
            this.patients = await this.healthChecksService.getAllPatientsWithSupervisors();
            this.loading = false; 
        } catch (error) {
            console.error('Error fetching patients with supervisors:', error);
            this.loading = false; 
        }
    },
  },
  created() {
        this.getAllPatientsWithSupervisors();
  }
});
</script>

<style>

</style>