import axios from 'axios';

const BASE_URL = 'http://localhost:3000';

export class HealthChecksService {
    async getAllPatientsWithSupervisors() {
        try {
            const [patients, exams, examiners] = await Promise.all([
                axios.get(`${BASE_URL}/patients`),
                axios.get(`${BASE_URL}/mental-state-exams`),
                axios.get(`${BASE_URL}/examiners`)
            ]);
            
            const patientsMap = patients.data.reduce((map, patient) => {
                map[patient.id] = patient;
                return map;
            }, {});

            const examinersMap = examiners.data.reduce((map, examiner) => {
                map[examiner.id] = examiner;
                return map;
            }, {});

            return exams.data.map(exam => {
                const patient = patientsMap[exam.patientId];
                const examiner = examinersMap[exam.examinerId];
                const score = exam.orientationScore + exam.registrationScore + exam.attentionAndCalculationScore + exam.recallScore + exam.languageScore;
                return {
                    id: patient.id,
                    fullName: `${patient.firstName} ${patient.lastName}`,
                    photoUrl: patient.photoUrl,
                    birthDate: patient.birthDate,
                    supervisor: `${examiner.firstName} ${examiner.lastName}`,
                    nationalProviderIdentifier: `${examiner.nationalProviderIdentifier}`,
                    examDate:exam.examDate,
                    score: score
                };
            });
        } catch (error) {
            console.error('Error fetching patients with supervisors:', error);
            throw error;
        }
    }
}
