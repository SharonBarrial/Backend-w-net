<script setup>
import TheSidebarComponent from '@/core/public/components/the-sidebar.component.vue'

</script>

<template>
  <the-sidebar-component></the-sidebar-component>
  <router-view></router-view>
</template>

<style scoped>


</style>
