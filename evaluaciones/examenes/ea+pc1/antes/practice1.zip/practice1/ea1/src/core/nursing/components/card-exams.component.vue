<script>
import { defineComponent } from "vue";
import { ExamsService } from '@/core/nursing/services/exams.service.js'

export default defineComponent({
  name: "card-exams",
  data() {
    return {
      examsService: new ExamsService(),
      examiners: [],
      loading: false,
    }
  },
  methods: {
    async getAllPatientsWithSupervisors() {
      try {
        this.loading = true;
        this.examiners = await this.examsService.getAllPatientsWithSupervisors();
        this.loading = false;
      } catch (error) {
        console.error('Error fetching patients with supervisors:', error);
        this.loading = false;
      }
    },
  },
  created() {
    this.getAllPatientsWithSupervisors();
  }
});
</script>

<template>
  <div class="container-patients">
    <pv-card class="patients" v-for="examiner in examiners" :key="examiner.id">
      <template #header>
      </template>
        <p>{{examiner.firstName}}</p>
    </pv-card>
  </div>

</template>



<style scoped>

h3{
  font-weight:bold;
}

h4{
  font-size: 1rem;
  font-weight: bold;
}

.container-patients{
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
  gap: 2rem;
  padding: 20px;
  background-color: lightslategray;
}

.patients{
  border: 1px solid #181818;
  border-radius: 10px;
  box-sizing: border-box;
  min-height: 470px;
  background-color: lightgray;
}

</style>