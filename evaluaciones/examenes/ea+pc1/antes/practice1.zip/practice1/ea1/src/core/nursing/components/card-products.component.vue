<script>
import { Product } from '@/core/nursing/models/product.entity.js'

export default {
  name: 'product-card',
  props: {
    product: Product
  }
}
</script>

<template>
  <pv-card>
    <template #title>
      <h2>{{product.title}}</h2>
    </template>
    <template #subtitle>
      <img :src="product.photoUrl" alt="product.title" />
    </template>
    <template #content>
      <p>{{product.description}}</p>
      <p>$ {{product.price.toFixed(2)}}</p>
      <pv-rating :model-value="product.rating" :stars="5" :cancel="false"></pv-rating>
    </template>
  </pv-card>

</template>

<style scoped>

</style>