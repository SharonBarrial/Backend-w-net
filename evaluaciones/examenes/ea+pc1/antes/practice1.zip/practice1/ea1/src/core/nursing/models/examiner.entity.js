export class Examiner {
    constructor(id, firstName, lastName, nationalProviderIdentifier) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.nationalProviderIdentifier = nationalProviderIdentifier;
    }
}