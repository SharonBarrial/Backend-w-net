<script >
import cardProducts from '@/core/nursing/components/card-products.component.vue'
import { CollectionService } from '@/core/nursing/services/collection.service.js'
import { Product } from '@/core/nursing/models/product.entity.js'

export default {
  name: "drinkware-view",
  components: { cardProducts },
  data(){
    return {
      products: [],
      collectionService: new CollectionService(),
    };
  },

  created(){
    this.collectionService.getProducts(1).then(response => {
      this.products = response.data.map(product => new Product(product.id,
        product.title, product.description, product.photoUrl,
        product.price, product.collectionId, product.rating));
    });
  }
}

</script>

<template>
  <div class="container">
    <h1>Drinkware</h1>
    <div class="products">
      <div v-for="product in products" :key="product.id">
        <card-products :product="product" />
      </div>
    </div>
  </div>
</template>

<style scoped>

.container h1{
  color: #181818;
  text-align: center;
  font-size: 3rem;
}

.products {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 2rem;
  padding: 20px;
}

.products div{
  border: 1px solid #181818;
  border-radius: 10px;
  box-sizing: border-box;
  min-height: 470px;
  background-color: lightgray;
}

.container{
  background-color: lightslategray;
  width: 100vw;
  height: 100vh;
}

@media screen and (max-width: 450px) {
  .products{
    grid-template-columns: 1fr;
  }
}
</style>