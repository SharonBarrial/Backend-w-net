<script>

import theToolbarComponent from '@/core/public/components/the-toolbar.component.vue'
import CardExams from '@/core/nursing/components/card-exams.component.vue'

export default {
  name: 'exams-view.component',
  components: { CardExams, theToolbarComponent}
}
</script>

<template>
  <the-toolbar-component></the-toolbar-component>
  <div class="container">
    <h1>Exams</h1>
    <card-exams></card-exams>
  </div>
</template>

<style scoped>

.container{
  background-color: lightslategray;
  }

.container h1{
  color: #181818;
  text-align: center;
  font-size: 3rem;
}



</style>