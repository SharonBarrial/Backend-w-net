import { BaseService } from '@/core/shared/base.service.js'
import axios from 'axios'

export class ExamsService extends BaseService {
  constructor() {
    super('exams')
    this.endpoint = 'http://localhost:3000';
  }

  async getAllPatientsWithSupervisors() {
    try {
      const [ exams, examiners] = await Promise.all([
        axios.get(`${this.endpoint}/mental-state-exams`),
        axios.get(`${this.endpoint}/examiners`)
      ]);

      const examinersMap = examiners.data.reduce((map, examiner) => {
        map[examiner.id] = examiner;
        return map;
      }, {});

      return exams.data.map(exam => {
        const examiner = examinersMap[exam.examinerId];
        const score = exam.orientationScore + exam.registrationScore + exam.attentionAndCalculationScore + exam.recallScore + exam.languageScore;
        return {
          id: examiner.id,
          fullName: `${examiner.firstName} ${examiner.lastName}`,
          nationalProviderIdentifier: `${examiner.nationalProviderIdentifier}`,
          score: score
        };
      });
    } catch (error) {
      console.error('Error fetching patients with supervisors:', error);
      throw error;
    }
  }
}
