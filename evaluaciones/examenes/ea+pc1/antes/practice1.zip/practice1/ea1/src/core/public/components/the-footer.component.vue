<script>
export default {
  name: "the-footer"
}
</script>

<template>
  <footer class="bg-gray-800 text-white text-center p-4">
    <p> ©2024 - All rights reserved</p>
    <p>Developed by Sharon Antuanet Ivet Barrial Marin u202114900 </p>
  </footer>
</template>

<style scoped>

</style>