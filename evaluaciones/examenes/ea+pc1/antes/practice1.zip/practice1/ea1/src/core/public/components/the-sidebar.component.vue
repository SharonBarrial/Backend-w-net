<script>
// This component will be used to display the sidebar in the application,
// to navigate through the application, to contain links to the different pages of the application
// also to contain buttons to change the language of the application
// For changing the language of the application use the $i18n.locale variable

import { ref  } from 'vue'

export default {
  name: "the-sidebar-component",
  setup() {
      //This variable will be used to show or hide the sidebar
      const visible =ref(false);
      return { visible };
  },
}

</script>

<template>
  <div class="card flex justify-content-center" >
    <pv-sidebar v-model:visible="visible" header="Sidebar">
      <template #header>
        <img src="https://hign.org/sites/default/files/2022-01/HIGN-logo-1200.png" alt="Logo" style="width: 70px; height: 20px">
      </template>
      <div class="container-options" >
        <router-link to="/home" class="link-style">Home</router-link>
        <router-link to="/collections/all-drinkware" class="link-style">Drinkware</router-link>
        <router-link to="/collections/accessories" class="link-style">Accesories</router-link>
        <router-link to="/exams-mental-health" class="link-style">Exams Mental</router-link>
        <span class="spacer"></span>
        <div class="container-btn">
          <pv-button @click="$i18n.locale= 'en'">EN</pv-button>
          <pv-button @click="$i18n.locale= 'es'">ES</pv-button>
        </div>

        </div>
    </pv-sidebar>
    <pv-button icon="pi pi-bars" @click="this.visible = true" />
  </div>
</template>

<style scoped>

.card{
  position:absolute;
  top: 15px;
  left: 20px;
  z-index: 6;
}

.container-options{
  display: flex;
  flex-direction: column;
  padding: 2px 2px 2px 5px;
  gap: 20px;
  margin: 0 5rem 0 0;
  /*text-align: center;
  justify-content: center;
  align-content: center;
  align-items: center;*/
}

.link-style{
  font-size: 1.2em;
  cursor: pointer;
  font-weight: bold;
  color: black;
  text-decoration: none;
}

.container-btn{
  display: flex;
  gap: 10px;
  align-items: center;
}

.spacer{
  flex-grow: 1;
}

</style>