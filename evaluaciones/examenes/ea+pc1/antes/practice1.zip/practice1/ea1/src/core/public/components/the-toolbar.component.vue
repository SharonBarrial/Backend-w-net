<script>

export default {
  name: 'the-toolbar-component',
  components: { }
}
</script>

<template>
<pv-toolbar role= "banner">
    <template #start>
      <img src="https://hign.org/sites/default/files/2022-01/HIGN-logo-1200.png" alt="Logo" style="width: 140px; height: 30px">
    </template>
  <template #end >
    <div class="container-options" >
        <router-link to="/home" class="link-style">Home</router-link>
        <router-link to="/collections/all-drinkware" class="link-style">Drinkware</router-link>
        <router-link to="/collections/accessories" class="link-style">Accesories</router-link>
        <router-link to="/exams-mental-health" class="link-style">Exams</router-link>
      <router-link to="/resumen" class="link-style">Resumen</router-link>
        <span class="spacer"></span>
        <div class="container-btn">
          <pv-button  @click="$i18n.locale= 'en'">EN</pv-button>
          <pv-button @click="$i18n.locale= 'es'">ES</pv-button>
        </div>
    </div>
  </template>
  </pv-toolbar>
</template>

<style scoped>

img{
  padding-left: 60px;
}

.container-options{
  display: flex;
  padding: 2px 2px 2px 2px;
  gap: 10px;
  margin: 0 1rem 0 0;
  /*text-align: center;
  justify-content: center;
  align-content: center;
  align-items: center;*/
}

.link-style{
  padding-top: 5px;
  text-decoration: none;
  font-size: 1.1em;
  cursor: pointer;
  font-weight: bold;
  color: black;
}

.container-btn{
  gap:50px;
}

pv-button:active {
  background-color: #4CAF50;
}

</style>