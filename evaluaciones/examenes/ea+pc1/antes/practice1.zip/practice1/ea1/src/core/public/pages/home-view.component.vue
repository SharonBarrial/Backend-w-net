<script >
export default {
  name: "home-page",
  data() {
    return {
      HeroSectionPhrase: "HeroSectionPhrase",
    }
  }
}

</script>

<template>
  <div class="container-home">
    <div class="hero-section">
      <h3 class="hero-section-phrase">{{ $t('HeroSectionPhrase')}}</h3>
      <br>

    </div>
    <img class="image-background" src="https://hign.org/sites/default/files/carousel-images/2022-02/iStock-945439872.jpg"
         alt="Hero image">
  </div>
</template>

<style scoped>
.image-background{
  width: 100%;
  height: 100vh;
  object-fit: cover;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 0;
}
.hero-section {
  position: relative;
  z-index: 2;
  text-align: center;
  border-radius: 10px;
  background-color: rgba(0, 0, 0, 0.5);
  padding: 30px;
  margin: 0 290px;
}

.hero-section-phrase {
  text-align: center;
  padding: 20px
}

h3{
  font-size: 3em;
  color: azure;
  text-shadow: black -1px 5px 10px;
  line-break: inherit;
  line-height: 8dvb;
  font-weight: bolder;
  font-family: 'Roboto', sans-serif;
  justify-items: center;
}

.container-home::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.4);
  z-index: 1;
}


.container-home{
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.hero-section-btn{
  display: flex;
  justify-content: center;
  gap: 20px;
}

pv-button{
  background-color: mediumpurple; /* Green background */
  border: none; /* Remove border */
  color: white; /* White text */
  padding: 15px 32px; /* Some padding */
  text-align: center; /* Centered text */
  text-decoration: none; /* Remove underline */
  display: inline-block; /* Get it to display inline */
  font-size: 16px;
  cursor: pointer;
  font-weight: bold;
  border-radius: 10px;
  margin: 0 1rem 0 0;
  /*text-align: center;
  justify-content: center;
  align-content: center;
  align-items: center;*/
}

@media screen and (max-width: 400px) {
  .hero-section{
    margin: 10px 20px;
  }
}
</style>