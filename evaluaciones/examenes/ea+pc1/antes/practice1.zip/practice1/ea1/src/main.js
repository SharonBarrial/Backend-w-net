import './assets/main.css'

/*Here we import the PrimeVue library and its services, components, and styles.
We also import the PrimeIcons and PrimeFlex libraries, the theme,
the i18n configuration, and the router configuration.
 */
import PrimeVue from 'primevue/config'
import 'primeflex/primeflex.css';
import 'primeicons/primeicons.css';
import 'primevue/resources/themes/aura-light-purple/theme.css'
import i18n from "@/locales/i18n";


import router from '@/router/index.js'

import Sidebar from 'primevue/sidebar'
import Button from 'primevue/button'
import Toolbar from 'primevue/toolbar'
import SelectButton from 'primevue/selectbutton';
import Dropdown from 'primevue/dropdown'
import Card from 'primevue/card'
import Rating from 'primevue/rating'


import { createApp } from 'vue'
import App from './App.vue'

const app= createApp(App)
app
  .use(PrimeVue)
  .use(router)
  .use(i18n)
  .component('pv-sidebar', Sidebar)
  .component('pv-button', Button)
  .component('pv-toolbar', Toolbar)
  .component('pv-selectbutton', SelectButton)
  .component('pv-dropdown', Dropdown)
  .component('pv-card', Card)
  .component('pv-rating', Rating)



app.mount('#app')
