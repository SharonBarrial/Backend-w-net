// This file contains the routes for the application and is used
// by the router to navigate between pages. The routes are defined as an
// array of objects, where each object represents a route.

import HomeView from "@/core/public/pages/home-view.component.vue";
import PageNotFound from "@/core/public/pages/page-not-found.component.vue";
import DrinkwareView from '@/core/nursing/pages/drinkware-view.component.vue';
import AccesoriesView from '@/core/nursing/pages/accesories-view.component.vue';
import ExamsView from '@/core/nursing/pages/exams-view.component.vue'

export const routes = [
  {
    path: "/home",
    name: "Home View",
    component: HomeView,
  },
  {
    path: "/collections/all-drinkware",
    name: "Drinkware",
    component: DrinkwareView,
  },
  {
    path: "/collections/accessories",
    name: "Accesories",
    component: AccesoriesView,
  },
  {
    path: "/exams-mental-health",
    name: "Exams Mental Health",
    component: ExamsView,
  },
  {
    path: "/resumen",
    name: "Resumen",
    component: () => import("@/core/nursing/pages/resumen-view.component.vue"),
  },
  {
    //This is the default route
    path: "/",
    redirect: "/home",
  },
  {
    path: "/:pathMatch(.*)*",
    name: "Page Not Found",
    component: PageNotFound
  },
]